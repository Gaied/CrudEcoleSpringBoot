package spring004web.entity;

public enum Sexe {
	
	HOMME, FEMME
	
}
